class Persona():
    def __init__(self , nombre , apellido , dni , mail):
        self.nombre = nombre
        self.apellido = apellido
        self.dni = dni
        self.mail = mail
    def __str__(self):
        return f"nombre: {self.nombre} mail: {self.mail}"