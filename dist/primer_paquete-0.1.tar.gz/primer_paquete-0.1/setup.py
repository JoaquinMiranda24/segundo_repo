from setuptools import setup

setup( 
       name = "primer_paquete" ,
       version = "0.1",
       description = "Primer paquete python",
       author = "Joaquin Miranda",
       packages = ["primer_paquete"],
)